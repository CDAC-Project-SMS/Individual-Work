package com.app.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.type.descriptor.sql.VarcharTypeDescriptor;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@Entity
@Table(name="students")
public class Student {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
@Column(name = "stud_fname",nullable = false)
private String fName;
@Column(name = "stud_mname",length=20)
private String mName;
@Column(name = "stud_lname",length=20)
private String lName;
@Column(name = "stud_roll")
private String roll;
@Column(name = "stud_mother_name")
private String motherName;
@Column(name = "stud_mob",length=20,nullable = false)
private String mobileNo;
@Column(name = "stud_email",nullable = false)
private String email;
@Column(name = "stud_address")
private String address;
@Column(name = "stud_blood_grp")
private String bloodGroup;
@Column(name = "stud_aadhar",nullable = false)
private String aadhar;
@Column(name = "course_id",nullable = false)
private String courseId;


}
