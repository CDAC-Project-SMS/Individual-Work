package com.app.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "Head")
public class Head {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "head_fname",nullable = false)
	private String fName;
	@Column(name = "head_mname",length=20)
	private String mName;
	@Column(name = "head_lname",length=20)
	private String lName;
	@Column(name = "head_qualification")
	private String qualification;
	
	@Column(name = "head_mob",length=20,nullable = false)
	private String mobileNo;
	@Column(name = "head_email",nullable = false)
	private String email;
	@Column(name = "head_address")
	private String address;
	@Column(name = "staff_category",nullable = false)
	private String category;
	
	@OneToOne
	private Organization organization;
	
}
