package com.app.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name="faculty")
public class Faculty {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
@Column(name = "fac_fname",nullable = false,length=20)
private String fac_fName;
@Column(name = "fac_mname",nullable = false,length=20)
private String fac_mName;
@Column(name = "fac_lname",nullable = false,length=20)
private String fac_lName;
@Column(name = "fac_mob",nullable = false,length=20)
private String fac_mob;
@Column(name = "fac_address",nullable = false,length=20)
private String fac_address;
@Column(name = "fac_qualification",nullable = false,length=20)
private String fac_qualification;


@OneToMany 
@JoinColumn(name = "fac_idstring",nullable = false)
private String sub_id;



}
