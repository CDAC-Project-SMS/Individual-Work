package com.app.exception_handler;

public class GlobalExceptionHandler {

}
