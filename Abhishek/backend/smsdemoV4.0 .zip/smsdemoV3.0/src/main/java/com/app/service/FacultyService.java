package com.app.service;

import java.util.List;

import com.app.dto.FacultyDto;
import com.app.entities.Faculty;



public interface FacultyService {

	List<FacultyDto> getAllFacultyList();
	FacultyDto saveFaculty(FacultyDto facultyDto);

//	ProductDTO addNewProduct(ProductDTO productDTO,Integer providerID);
//
//	String deleteProduct(Integer providerID);

}
