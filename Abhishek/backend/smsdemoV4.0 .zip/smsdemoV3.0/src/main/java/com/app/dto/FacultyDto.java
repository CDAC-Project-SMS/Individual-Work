package com.app.dto;

import java.util.List;

import javax.persistence.Column;

public class FacultyDto {
	
	private int id;
	private String facultyFirstName;
	private String facultyLastName;
	private String facultyMiddleName;
	private String facultyAddress;
	private String facultyQualification;
	private String facultyMob;
	
	

//	SubjectDto subjectDto;
//	Long subjectId=subjectDto.getId();
	private List<Long> subjectIdList;
	
	
	public FacultyDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFacultyFirstName() {
		return facultyFirstName;
	}

	public void setFacultyFirstName(String facultyFirstName) {
		this.facultyFirstName = facultyFirstName;
	}

	public String getFacultyLastName() {
		return facultyLastName;
	}

	public void setFacultyLastName(String facultyLastName) {
		this.facultyLastName = facultyLastName;
	}

	public String getFacultyMiddleName() {
		return facultyMiddleName;
	}

	public void setFacultyMiddleName(String facultyMiddleName) {
		this.facultyMiddleName = facultyMiddleName;
	}

	public String getFacultyAddress() {
		return facultyAddress;
	}

	public void setFacultyAddress(String facultyAddress) {
		this.facultyAddress = facultyAddress;
	}

	public String getFacultyQualification() {
		return facultyQualification;
	}

	public void setFacultyQualification(String facultyQualification) {
		this.facultyQualification = facultyQualification;
	}

	public String getFacultyMob() {
		return facultyMob;
	}

	public void setFacultyMob(String facultyMob) {
		this.facultyMob = facultyMob;
	}

	@Override
	public String toString() {
		return "FacultyDto [id=" + id + ", facultyFirstName=" + facultyFirstName + ", facultyLastName="
				+ facultyLastName + ", facultyMiddleName=" + facultyMiddleName + ", facultyAddress=" + facultyAddress
				+ ", facultyQualification=" + facultyQualification + ", facultyMob=" + facultyMob + "]";
	}



	
	
	


}
