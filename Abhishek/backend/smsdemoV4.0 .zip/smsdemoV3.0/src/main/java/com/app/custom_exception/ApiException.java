package com.app.custom_exception;

public class ApiException {

}
