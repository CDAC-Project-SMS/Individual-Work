package com.app.dto;



public class SubjectDto {

	private Long id;

	private String subjectName;
	
	private Integer subjectTotalMarks;

	public SubjectDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}

	public Integer getSubjectTotalMarks() {
		return subjectTotalMarks;
	}

	public void setSubjectTotalMarks(Integer subjectTotalMarks) {
		this.subjectTotalMarks = subjectTotalMarks;
	}

	@Override
	public String toString() {
		return "SubjectDto [id=" + id + ", subjectName=" + subjectName + ", subjectTotalMarks=" + subjectTotalMarks
				+ "]";
	}
	
}
