package com.app.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name="faculty")
public class Faculty {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
@Column(name = "fac_fname",nullable = false,length=20)
private String facultyFirstName;
@Column(name = "fac_mname",nullable = false,length=20)
private String facultyMiddleName;
@Column(name = "fac_lname",nullable = false,length=20)
private String facultyLastName;
@Column(name = "fac_mob",nullable = false,length=20)
private String facultyMob;
@Column(name = "fac_address",nullable = false,length=20)
private String facultyAddress;
@Column(name = "fac_qualification",nullable = false,length=20)
private String facultyQualification;


@ManyToMany(mappedBy = "faculties", cascade = {CascadeType.ALL} ,fetch = FetchType.EAGER)
private List<Subjects> subjects;
//
//@ManyToOne
//@JoinColumn(name="fk_org_id")
//private Organization organization;


}
