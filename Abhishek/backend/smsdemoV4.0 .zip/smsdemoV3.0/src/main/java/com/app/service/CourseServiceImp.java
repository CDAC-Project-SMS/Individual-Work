package com.app.service;

public class CourseServiceImp {
	
	//
//	@Override
//	public CourseDto updateCourse(@Valid CourseDto dto, Integer courseId) {
//
//		Course c = courDao.getReferenceById(courseId);
//
//		Course cour = mapper.map(dto, Course.class);
//
//		if (Period.between(cour.getStartDate(), cour.getEndDate()).getMonths() <= 0)
//			throw new GenericException("End date has to be later than start date.");
//
//		c.setStartDate(cour.getStartDate());
//		c.setEndDate(cour.getEndDate());
//		c.setFees(cour.getFees());
//
//		courDao.save(c);
//
//		return mapper.map(c, CourseDto.class);
//
//	}

}
