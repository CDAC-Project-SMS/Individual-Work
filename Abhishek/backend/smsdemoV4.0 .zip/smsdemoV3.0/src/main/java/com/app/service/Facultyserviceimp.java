package com.app.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityNotFoundException;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.FacultyDao;
import com.app.dto.FacultyDto;

import com.app.entities.Faculty;




@Service
public class Facultyserviceimp implements FacultyService {

	@Autowired
	private ModelMapper mapper;
	@Autowired
	FacultyDao facultyDao;
	
	
	
	
	@Override
	public List<FacultyDto> getAllFacultyList() {
		// TODO Auto-generated method stub
		List<Faculty> list = facultyDao.findAll();
		list.forEach(e->System.out.println(e));
		return list.stream().map(p->  mapper.map(p, FacultyDto.class)).collect(Collectors.toList());}
		/*
		 * List<Product> list = productDao.findAll();
		list.forEach(e->System.out.println(e));
		
		return list.stream().map(p->  mapper.map(p, ProductDTO.class)).collect(Collectors.toList());
		
		
		//return facultyDao.findAll();
		
		
		public ProductDTO addNewProduct(ProductDTO productDTO,Integer providerID) {
			Product product = mapper.map(productDTO, Product.class);
			
		User user = userDao.findById(providerID).orElseThrow(()-> new EntityNotFoundException("provider id not found"));
			
			product.setProvider(user);
			Product p = productDao.save(product);
			return mapper.map(p, ProductDTO.class);
		}

	}*/

	@Override
	public FacultyDto saveFaculty(FacultyDto facultyDto) {
		// TODO Auto-generated method stub
		Faculty faculty=mapper.map(facultyDto, Faculty.class);
		Faculty faculty2= facultyDao.save(faculty);
		FacultyDto facultyDto2=mapper.map(facultyDto, FacultyDto.class);
		return facultyDto2;
	}

}
