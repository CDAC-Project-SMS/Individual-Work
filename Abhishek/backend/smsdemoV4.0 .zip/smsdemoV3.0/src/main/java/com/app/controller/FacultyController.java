package com.app.controller;
 
import java.util.List;

import javax.security.auth.Subject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.FacultyDto;

import com.app.entities.Faculty;
import com.app.entities.Subjects;
import com.app.service.Facultyserviceimp;


@RestController
@RequestMapping("/Faculty")
public class FacultyController {

	@Autowired
	Facultyserviceimp facultyservice;
	
	@PostMapping("/saveFaculty")
	public FacultyDto saveFaculty(@RequestBody FacultyDto facultyDto){
		return facultyservice.saveFaculty(facultyDto);
		
	}
	@GetMapping("/allfacultylist")
	public List<FacultyDto> getAllFacultyList() {
		return facultyservice.getAllFacultyList();
	}
	
	/*
	 * @Autowired
	private ProductService productService;
	
	
	@GetMapping("/list")
	public List<ProductDTO> getAllProducts() {
		return productService.getAllProducts();
	}
	
	
	@PostMapping("/addProduct/{providerID}")
	public ProductDTO addProduct(@RequestBody ProductDTO productDTO,@PathVariable Integer providerID) {
		
		return productService.addNewProduct(productDTO,providerID);
	}
	
	@DeleteMapping("/delete/{productID}")
	public String deleteProduct(@PathVariable Integer productID) {
		return productService.deleteProduct(productID);
	}*/
	
}
