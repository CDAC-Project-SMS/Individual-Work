package com.app.entities;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "Transactions")
public class Transactions {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	//<!--check whether @notation is right or wrong -->	
//	@ManyToOne
	@OneToOne
	@JoinColumn(name = "fees_id",nullable = false)
	private Long feesId;
	@Column(name = "trans_amount")
	private Double transactionAmount;
	@Column(name = "trans_timestamp")
	private LocalTime transactionTimeStamp;
}
