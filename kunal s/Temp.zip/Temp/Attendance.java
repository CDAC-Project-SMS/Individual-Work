package com.app.entities;
import java.time.LocalTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Entity
@Table(name = "Attendance")
public class Attendance {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	@Column(name = "att_timestamp",length=20)
	private LocalTime attendanceTimestamp;
	//<!--@notation is missing(many to many)-->	
		@ManyToOne
		@JoinColumn(name = "stud_id",nullable = false)
		private Long studentId;
		//<!--@notation is missing(many to many)-->	
		@OneToOne 
		@JoinColumn(name = "sched_id",nullable = false)
		private Long scheduleId;
}
