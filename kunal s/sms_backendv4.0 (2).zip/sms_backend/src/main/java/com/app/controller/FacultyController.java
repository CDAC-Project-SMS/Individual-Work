package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.FacultyDto;
import com.app.service.impl.FacultyImpl;

@RestController
@RequestMapping("/Faculty")
public class FacultyController {

	@Autowired
	FacultyImpl facultyservice;
	
	@PostMapping("/saveFaculty")
	public FacultyDto saveFaculty(@RequestBody FacultyDto facultyDto){
		return facultyservice.saveFaculty(facultyDto);
		
	}
	@GetMapping("/allFacultyList")
	public List<FacultyDto> getAllFacultyList() {
		return facultyservice.getAllFacultyList();
	}
}
