package com.app.dto;

import java.util.List;

import com.app.entities.primary.Organization;
import com.app.entities.secondary.Address;
import com.app.entities.secondary.Subject;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
public class FacultyDto {
	
	@Getter
	@Setter
	private String facFName;
	@Getter
	@Setter
	private String facMName;
	@Getter
	@Setter
	private String facLName;
	@Getter
	@Setter
	private String facMobNo;
	@Getter
	@Setter
	private Address facAddress;
	@Getter
	@Setter
	private String facQualif;
	@Getter
	@Setter
	private String email;
	@Getter
	@Setter
	private String password;
	
	
	private Organization organization;
	
	//private Long orgId=organization.getOrgId();
	@Getter
	@Setter
	private Long orgId =organization.getOrgId();

	@Override
	public String toString() {
		return "FacultyDto [facFName=" + facFName + ", facMName=" + facMName + ", facLName=" + facLName + ", facMobNo="
				+ facMobNo + ", facAddress=" + facAddress + ", facQualif=" + facQualif + ", email=" + email
				+ ", password=" + password + ", organization=" + organization + ", orgId=" + orgId + "]";
	}
	

/*
 * private long facId;
	
	@Column(name="f_name",length = 50)
	private String facFName;
	
	@Column(name="m_name",length = 50)
	private String facMName;
	
	@Column(name="l_name",length = 50)
	private String facLName;
	
	@Column(name="mob_no",length = 15)
	private String facMobNo;
	
	@Column(name="address")
	@Embedded
	private Address facAddress;
	
	@Column(name="qualification",length = 50)
	private String facQualif;
	
	@Column(length = 60)
	private String email;
	
	@Column(length = 90)
	private String password;
	
	@ManyToOne
	@JoinColumn(name = "org_id",nullable = false)
	private Organization organization;
	
	@ManyToMany
	@JoinTable(name = "faculty_subject",
				joinColumns = @JoinColumn(name="fac_id"),
				inverseJoinColumns = @JoinColumn(name="sub_id"))
	private List<Subject> subjects;
 * 
 * */
}
