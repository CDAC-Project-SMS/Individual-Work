package com.app.service;

import java.util.List;

import com.app.dto.FacultyDto;


public interface FacultyService {

	public FacultyDto saveFaculty(FacultyDto facultyDto) ;

	public List<FacultyDto> getAllFacultyList();
	
}
