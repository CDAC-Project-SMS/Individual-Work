package com.app.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.dao.FacultyDao;
import com.app.dto.FacultyDto;
import com.app.entities.primary.Faculty;
import com.app.service.FacultyService;

@Service
public class FacultyImpl implements FacultyService {
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	FacultyDao facultyDao;

	@Override
	public FacultyDto saveFaculty(FacultyDto facultyDto) {
		// TODO Auto-generated method stub
		 Faculty faculty=mapper.map(facultyDto, Faculty.class);
		Faculty faculty2= facultyDao.save(faculty);
		FacultyDto facultyDto2=mapper.map(facultyDto, FacultyDto.class);
		return facultyDto2;
		
		
	}

	@Override
	public List<FacultyDto> getAllFacultyList() {
		// TODO Auto-generated method stub
		
		List<Faculty> list = facultyDao.findAll();
		list.forEach(e->System.out.println(e));
		return list.stream().map(p->  mapper.map(p, FacultyDto.class)).collect(Collectors.toList());}


	
}
